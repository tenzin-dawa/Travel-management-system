<div class="copyrights">
	 <p>© 2022 TMS created by Dawa and Chirag. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
