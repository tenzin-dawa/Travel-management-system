<?php 
require_once("includes/config.php");
// code password validation
if(!empty($_POST["number"])) {
	$number= $_POST["number"];

if(strlen($number) < 10 || strlen($number) > 10) {
    echo "<span style='color:red'>Mobile number should have 10 numbers </span>";
    echo "<script>$('#submit').prop('disabled',true);</script>";   

}
else{
    echo "<span style='color:green'>Valid number</span>";
    echo "<script>$('#submit').prop('disabled',false);</script>"; 
    
}

}


?>